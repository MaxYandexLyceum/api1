import datetime
import sqlalchemy
from flask import session
from sqlalchemy import orm
from sqlalchemy_serializer import SerializerMixin

from data.db_session import SqlAlchemyBase


class Hazard_Categories(SqlAlchemyBase, SerializerMixin):
    __tablename__ = 'hazard_category'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    title = sqlalchemy.Column(sqlalchemy.String, nullable=True)
