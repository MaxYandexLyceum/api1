import requests

params = {"id": 10, "job": "da", "team_leader": 1, "work_size": 2, "collaborators": "1,2,3", "hazard": 1, "is_finished": 0}
c = requests.post(url="http://127.0.0.1:5000/api/jobs/edit", json=params)
print(c.json())
# {'success': 'OK'}

params1 = {"id": 12343125235, "job": "da", "team_leader": 1, "work_size": 2, "collaborators": "1,2,3", "hazard": 1, "is_finished": 0}
c1 = requests.post(url="http://127.0.0.1:5000/api/jobs/edit", json=params1)
print(c1.json())
# {'ERROR': 'Job does not exist'} - неверный id

a = requests.get("http://127.0.0.1:5000/api/alljobs")
print(a.json())
# все работы
