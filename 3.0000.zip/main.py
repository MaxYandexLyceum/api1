import datetime

import flask
import requests
from flask import Flask, render_template, request
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.exceptions import abort
from werkzeug.utils import redirect

from data import db_session, jobs_api
from data.db_session import global_init
from data.departments import Department
from data.jobs import Jobs
from data.users import User
from forms.editdepartment import Editdepartment
from forms.department import Adddepartment
from forms.editjob import Editjob
from forms.job import Addjob
from forms.user import RegisterForm, LoginForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
global_init("db/scalchemy_base.db")

login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/addjob', methods=['GET', 'POST'])
def addjob():
    form = Addjob()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        job = Jobs(
            job=form.title.data,
            team_leader=int(form.team_lider_id.data),
            work_size=form.work_size.data,
            collaborators=form.collaborators.data,
            hazard_category=form.hazard.data,
            is_finished=form.is_finished.data
        )
        db_sess.add(job)
        db_sess.commit()
        return redirect('/')
    return render_template('addjob.html', form=form)


@app.route('/jobs/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_job(id):
    form = Editjob()
    if request.method == "GET":
        db_sess = db_session.create_session()
        jobs = db_sess.query(Jobs).filter(Jobs.id == id).first()
        if jobs:
            form.title.data = jobs.job
            form.team_lider_id.data = jobs.team_leader
            form.work_size.data = jobs.work_size
            form.collaborators.data = jobs.collaborators
            form.hazard.data = jobs.hazard_category
            form.is_finished.data = jobs.is_finished
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        jobs = db_sess.query(Jobs).filter(Jobs.id == id).first()
        cur = current_user.id
        if cur == 1 or cur == int(jobs.team_leader):
            if jobs:
                jobs.job = form.title.data
                jobs.team_lider = form.team_lider_id.data
                jobs.work_size = form.work_size.data
                jobs.collaborators = form.collaborators.data
                jobs.hazard_category = form.hazard.data
                jobs.is_finished = form.is_finished.data
                db_sess.commit()
                return redirect('/')
            else:
                abort(404)
        else:
            return render_template('editjob.html', message="Недостаточно прав", form=form)
    return render_template('editjob.html', form=form, message="")


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/')
def index():
    global indexes
    db_sess = db_session.create_session()
    d = []
    indexes = []
    for job in db_sess.query(Jobs).all():
        m = []
        indexes.append(job.id)
        m.append(job.id)
        m.append(job.job)
        for user in db_sess.query(User).filter(User.id == job.team_leader):
            m.append(user.name + " " + user.surname)
        m.append(job.work_size)
        m.append(job.collaborators)
        m.append(job.hazard_category)
        m.append(job.is_finished)
        d.append(m)
    return render_template('index.html', d=d, indexes=indexes)


@app.route('/departments')
def departments():
    global indexesdep
    db_sess = db_session.create_session()
    depart = []
    indexesdep = []
    for dep in db_sess.query(Department).all():
        m = []
        indexesdep.append(dep.id)
        m.append(dep.id)
        m.append(dep.title)
        for user in db_sess.query(User).filter(User.id == dep.chief):
            m.append(user.name + " " + user.surname)
        m.append(dep.members)
        m.append(dep.email)
        depart.append(m)
    return render_template('departments.html', d=depart, indexes=indexesdep)


@app.route('/adddepartment', methods=['GET', 'POST'])
def adddepartment():
    form = Adddepartment()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        department = Department(
            title=form.title.data,
            chief=int(form.chief.data),
            members=form.members.data,
            email=form.email.data,
        )
        db_sess.add(department)
        db_sess.commit()
        return redirect('/departments')
    return render_template('adddepartment.html', form=form)


@app.route('/departments/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_department(id):
    form = Editdepartment()
    if request.method == "GET":
        db_sess = db_session.create_session()
        department = db_sess.query(Department).filter(Department.id == id).first()
        if department:
            form.title.data = department.title
            form.chief.data = department.chief
            form.members.data = department.members
            form.email.data = department.email
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        department = db_sess.query(Department).filter(Department.id == id).first()
        cur = current_user.id
        if cur == 1 or cur == int(department.chief):
            if department:
                department.title = form.title.data
                department.chief = form.chief.data
                department.members = form.members.data
                department.email = form.email.data
                db_sess.commit()
                return redirect('/departments')
            else:
                abort(404)
        else:
            return render_template('editdepartment.html', message="Недостаточно прав", form=form)
    return render_template('editdepartment.html', form=form, message="")


@app.route('/departments_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def departments_delete(id):
    global indexesdep

    db_sess = db_session.create_session()
    department = db_sess.query(Department).filter(Department.id == id).first()
    cur = current_user.id
    if cur == 1 or cur == int(department.chief):
        if department:
            db_sess.delete(department)
            db_sess.commit()
            indexesdep.remove(id)
        else:
            abort(404)
    return redirect('/departments')

@app.route('/users_show/<int:id>', methods=['GET'])
def users_show(id):
    fullname = requests.get(f"http://127.0.0.1:5000/api/user/{id}").json()["user"]["name"] + " " + requests.get(f"http://127.0.0.1:5000/api/user/{id}").json()["user"]["surname"]
    city = requests.get(f"http://127.0.0.1:5000/api/user/{id}").json()["user"]["city_from"]

    geocoder_request1 = f"http://geocode-maps.yandex.ru/1.x/?apikey=40d1649f-0493-4b70-98ba-98533de7710b&geocode={city}&format=json"
    response1 = requests.get(geocoder_request1)
    json_response1 = response1.json()
    toponym1 = json_response1["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
    toponym_coodrinates1 = toponym1["Point"]["pos"]
    toponym_longitude1, toponym_lattitude1 = toponym_coodrinates1.split(" ")
    map_request = f"http://static-maps.yandex.ru/1.x/?ll={toponym_longitude1},{toponym_lattitude1}8&spn=0.1,0.1&l=sat"
    response = requests.get(map_request)

    # Запишем полученное изображение в файл.
    map_file = "static/map.png"
    with open(map_file, "wb") as file:
        file.write(response.content)

    return render_template('users_show.html', name=fullname, city=city)

@app.route('/jobs_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    global indexes

    db_sess = db_session.create_session()
    job = db_sess.query(Jobs).filter(Jobs.id == id).first()
    cur = current_user.id
    if cur == 1 or cur == int(job.team_leader):
        if job:
            db_sess.delete(job)
            db_sess.commit()
            indexes.remove(id)
        else:
            abort(404)
    return redirect('/')


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            surname=form.surname.data,
            age=int(form.age.data),
            position=form.position.data,
            speciality=form.speciality.data,
            name=form.name.data,
            email=form.email.data,
            address=form.address.data,
            hashed_password=form.password.data,
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


def main():
    try:
        job = Jobs()
        job.team_leader = 1
        job.job = "deployment of residential modules 1 and 2"
        job.work_size = 15
        job.collaborators = "2, 3"
        job.start_date = datetime.datetime.now()
        job.is_finished = False

        user = User()
        user.name = "Ridley"
        user.surname = "Scott"
        user.age = 21
        user.position = "captain"
        user.speciality = "research engineer"
        user.address = "module_1"
        user.email = "scott_chief@mars.org"

        user1 = User()
        user1.name = "Ridleya"
        user1.surname = "Scotta"
        user1.age = 22
        user1.position = "captaina"
        user1.speciality = "research engineear"
        user1.address = "module_1a"
        user1.email = "dadada@ok.com"

        user2 = User()
        user2.name = "Ridleyaa"
        user2.surname = "Scottaa"
        user2.age = 22
        user2.position = "captainaa"
        user2.speciality = "research engineeara"
        user2.address = "module_1aa"
        user2.email = "aaaa@aaaaa.ru"

        user3 = User()
        user3.name = "Ridleyaa"
        user3.surname = "Scottaa"
        user3.age = 22
        user3.position = "captainaa"
        user3.speciality = "research engineeara"
        user3.address = "module_1aa"
        user3.email = "fef@aaaaa.ru"

        db_sess = db_session.create_session()
        db_sess.add(job)
        db_sess.add(user)
        db_sess.add(user1)
        db_sess.add(user2)
        db_sess.add(user3)
        db_sess.commit()
    except Exception:
        pass
    app.register_blueprint(jobs_api.blueprint)
    app.run()


if __name__ == '__main__':
    main()
